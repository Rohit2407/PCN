// Simplified DNS-like lookup over UDP (not the real DNS wire protocol).
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#define PORT 8053
int main(void) {
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in a = {0}, c; socklen_t n = sizeof(c);
    char q[256], ans[256];
    a.sin_family = AF_INET; a.sin_addr.s_addr = INADDR_ANY; a.sin_port = htons(PORT);
    if (bind(s, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("bind"); return 1; }
    printf("DNS-like server on UDP port %d\\n", PORT);
    while (1) {
        memset(q, 0, sizeof(q)); recvfrom(s, q, sizeof(q)-1, 0, (struct sockaddr *)&c, &n);
        if (!strcmp(q, "example.com")) strcpy(ans, "93.184.216.34");
        else if (!strcmp(q, "localhost")) strcpy(ans, "127.0.0.1");
        else if (!strcmp(q, "google.com")) strcpy(ans, "142.250.0.0 (example only)");
        else strcpy(ans, "NXDOMAIN");
        sendto(s, ans, strlen(ans), 0, (struct sockaddr *)&c, n);
    }
}
