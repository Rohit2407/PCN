// Minimal HTTP/1.0 client for a local server at 127.0.0.1:8000.
#include <stdio.h>
#include <time.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
int main(void) {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    char request[] = "GET / HTTP/1.0\\r\\nHost: localhost\\r\\nConnection: close\\r\\n\\r\\n";
    char buf[1024]; int n;
    struct timespec start, end;
    double elapsed_ms;
    a.sin_family = AF_INET; a.sin_port = htons(8000);
    inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    if (connect(s, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("connect"); return 1; }
    clock_gettime(CLOCK_MONOTONIC, &start);
    send(s, request, strlen(request), 0);
    while ((n = recv(s, buf, sizeof(buf), 0)) > 0) fwrite(buf, 1, n, stdout);
    clock_gettime(CLOCK_MONOTONIC, &end);
    elapsed_ms = (end.tv_sec - start.tv_sec) * 1000.0
               + (end.tv_nsec - start.tv_nsec) / 1000000.0;
    printf("\n\nResponse time (send request until response ends): %.3f ms\n", elapsed_ms);
    close(s); return 0;
}
