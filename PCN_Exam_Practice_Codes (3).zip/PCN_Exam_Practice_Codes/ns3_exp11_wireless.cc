// Compact NS-3 wireless mobility template. All pairs use Wi-Fi ad hoc devices;
// traffic rates model different application loads, not separate Bluetooth/Zigbee PHYs.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include <iostream>
#include <cmath>
using namespace ns3;

void Run(double speed) {
    std::cout << "\\nNode speed: " << speed << " m/s\\n";
    NodeContainer nodes; nodes.Create(6);
    WifiHelper wifi; wifi.SetStandard(WIFI_STANDARD_80211n);
    YansWifiChannelHelper channel=YansWifiChannelHelper::Default();
    YansWifiPhyHelper phy; phy.SetChannel(channel.Create());
    WifiMacHelper mac; mac.SetType("ns3::AdhocWifiMac");
    NetDeviceContainer dev=wifi.Install(phy,mac,nodes);

    MobilityHelper mob; mob.SetMobilityModel("ns3::ConstantVelocityMobilityModel"); mob.Install(nodes);
    double x[6]={0,20,0,10,0,10}, y[6]={0,0,20,20,40,40};
    for (int i=0;i<6;i++) {
        Ptr<ConstantVelocityMobilityModel> m=nodes.Get(i)->GetObject<ConstantVelocityMobilityModel>();
        m->SetPosition(Vector(x[i],y[i],0));
        if (i==1 || i==3 || i==5) m->SetVelocity(Vector(speed,0,0));
    }

    InternetStackHelper internet; internet.Install(nodes);
    Ipv4AddressHelper ip;
    ip.SetBase("10.1.1.0","255.255.255.0");
    Ipv4InterfaceContainer a=ip.Assign(NetDeviceContainer(dev.Get(0),dev.Get(1)));
    ip.SetBase("10.1.2.0","255.255.255.0");
    Ipv4InterfaceContainer b=ip.Assign(NetDeviceContainer(dev.Get(2),dev.Get(3)));
    ip.SetBase("10.1.3.0","255.255.255.0");
    Ipv4InterfaceContainer c=ip.Assign(NetDeviceContainer(dev.Get(4),dev.Get(5)));

    uint16_t ports[3]={5000,6000,7000};
    Ipv4InterfaceContainer* ips[3]={&a,&b,&c};
    int src[3]={0,2,4}, dst[3]={1,3,5};
    char* rates[3]={(char*)"1Mbps",(char*)"500Kbps",(char*)"100Kbps"};
    uint32_t sizes[3]={512,256,100};
    for (int i=0;i<3;i++) {
        PacketSinkHelper sink("ns3::UdpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(),ports[i]));
        ApplicationContainer sa=sink.Install(nodes.Get(dst[i])); sa.Start(Seconds(0)); sa.Stop(Seconds(10));
        OnOffHelper source("ns3::UdpSocketFactory", InetSocketAddress(ips[i]->GetAddress(1),ports[i]));
        source.SetAttribute("DataRate", StringValue(rates[i]));
        source.SetAttribute("PacketSize", UintegerValue(sizes[i]));
        source.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
        source.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
        ApplicationContainer ca=source.Install(nodes.Get(src[i])); ca.Start(Seconds(1)); ca.Stop(Seconds(10));
    }

    phy.EnablePcap("exp11-wireless", dev.Get(0), true);
    FlowMonitorHelper fm; Ptr<FlowMonitor> mon=fm.InstallAll();
    Simulator::Stop(Seconds(10)); Simulator::Run(); mon->CheckForLostPackets();
    uint64_t tx=0,rx=0,bytes=0; double delay=0;
    for (auto f: mon->GetFlowStats()) { tx+=f.second.txPackets; rx+=f.second.rxPackets; bytes+=f.second.rxBytes; delay+=f.second.delaySum.GetSeconds(); }
    double loss=tx ? 100.0*(tx-rx)/tx : 0;
    double pdr=tx ? 100.0*rx/tx : 0;
    double thr=bytes*8.0/9.0/1e6;
    double avg=rx ? delay*1000.0/rx : 0;
    double distance=20.0+speed*5.0;
    double power=20.0-20.0*log10(distance); // rough illustrative estimate, not PHY measurement
    std::cout << "Throughput: " << thr << " Mbps\\nPDR: " << pdr << " %\\nPacket loss: " << loss
              << " %\\nAverage delay: " << avg << " ms\\nEstimated received power: " << power << " dB\\n";
    Simulator::Destroy();
}
int main() { Run(1); Run(5); Run(10); return 0; }
