// CRC sender using generator 10011. Sends a text-derived bit pattern for demonstration.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#define PORT 8090
int main(void) {
    int s, i, j; struct sockaddr_in a = {0};
    char data[100], bits[512] = {0}, work[512] = {0}, gen[] = "10011";
    printf("Enter a binary data string (e.g. 110101): "); scanf("%99s", data);
    for (i = 0; data[i]; i++) if (data[i] != '0' && data[i] != '1') { puts("Binary digits only"); return 1; }
    strcpy(bits, data); strcat(bits, "0000"); strcpy(work, bits);
    for (i = 0; i <= (int)strlen(data)-1; i++)
        if (work[i] == '1') for (j = 0; j < 5; j++) work[i+j] = (work[i+j] == gen[j]) ? '0' : '1';
    strcpy(bits, data); strcat(bits, work + strlen(data));
    s = socket(AF_INET, SOCK_STREAM, 0);
    a.sin_family = AF_INET; a.sin_port = htons(PORT); inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    if (connect(s, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("connect"); return 1; }
    send(s, bits, strlen(bits), 0); printf("Sent codeword: %s\\n", bits);
    close(s); return 0;
}
