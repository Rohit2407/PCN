// DNS-like UDP client with timeout.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <arpa/inet.h>
#define PORT 8053
int main(void) {
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in a = {0}; struct timeval tv = {3, 0};
    char q[256], ans[256] = {0};
    struct timespec start, end;
    double rtt;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    a.sin_family = AF_INET; a.sin_port = htons(PORT); inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    printf("Domain: "); scanf("%255s", q);
    clock_gettime(CLOCK_MONOTONIC, &start);
    sendto(s, q, strlen(q), 0, (struct sockaddr *)&a, sizeof(a));
    if (recvfrom(s, ans, sizeof(ans)-1, 0, NULL, NULL) < 0) puts("DNS request timed out");
    else {
        clock_gettime(CLOCK_MONOTONIC, &end);
        rtt = (end.tv_sec-start.tv_sec)*1000.0 + (end.tv_nsec-start.tv_nsec)/1000000.0;
        printf("Answer: %s\\nRTT: %.3f ms\\n", ans, rtt);
    }
    close(s); return 0;
}
