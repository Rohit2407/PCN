// NS-3 wired TCP/UDP flow performance template.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/traffic-control-module.h"
#include <iostream>
using namespace ns3;

int main() {
    NodeContainer n; n.Create(4);
    NodeContainer r; r.Create(2);
    PointToPointHelper access;
    access.SetDeviceAttribute("DataRate", StringValue("10Mbps"));
    access.SetChannelAttribute("Delay", StringValue("2ms"));
    access.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", StringValue("50p"));
    NetDeviceContainer d0=access.Install(n.Get(0),r.Get(0));
    NetDeviceContainer d1=access.Install(n.Get(1),r.Get(0));
    NetDeviceContainer d2=access.Install(r.Get(1),n.Get(2));
    NetDeviceContainer d3=access.Install(r.Get(1),n.Get(3));

    PointToPointHelper bottleneck;
    bottleneck.SetDeviceAttribute("DataRate", StringValue("2Mbps")); // change to 5Mbps, 10Mbps
    bottleneck.SetChannelAttribute("Delay", StringValue("10ms"));
    bottleneck.SetQueue("ns3::DropTailQueue<Packet>", "MaxSize", StringValue("50p"));
    NetDeviceContainer dr=bottleneck.Install(r.Get(0),r.Get(1));
    TrafficControlHelper tch; tch.Uninstall(dr);

    InternetStackHelper internet; internet.Install(n); internet.Install(r);
    Ipv4AddressHelper ip;
    ip.SetBase("10.0.1.0","255.255.255.0"); ip.Assign(d0);
    ip.SetBase("10.0.2.0","255.255.255.0"); ip.Assign(d1);
    ip.SetBase("10.0.3.0","255.255.255.0"); ip.Assign(dr);
    ip.SetBase("10.0.4.0","255.255.255.0"); Ipv4InterfaceContainer i2=ip.Assign(d2);
    ip.SetBase("10.0.5.0","255.255.255.0"); Ipv4InterfaceContainer i3=ip.Assign(d3);
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    uint16_t tp=5000, up=6000;
    PacketSinkHelper ts("ns3::TcpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(),tp));
    ApplicationContainer tsk=ts.Install(n.Get(3)); tsk.Start(Seconds(0)); tsk.Stop(Seconds(20));
    BulkSendHelper tc("ns3::TcpSocketFactory", InetSocketAddress(i3.GetAddress(1),tp));
    tc.SetAttribute("SendSize", UintegerValue(1024)); tc.SetAttribute("MaxBytes", UintegerValue(0));
    ApplicationContainer tsc=tc.Install(n.Get(0)); tsc.Start(Seconds(1)); tsc.Stop(Seconds(20));

    PacketSinkHelper us("ns3::UdpSocketFactory", InetSocketAddress(Ipv4Address::GetAny(),up));
    ApplicationContainer usk=us.Install(n.Get(2)); usk.Start(Seconds(0)); usk.Stop(Seconds(20));
    OnOffHelper uc("ns3::UdpSocketFactory", InetSocketAddress(i2.GetAddress(1),up));
    uc.SetAttribute("DataRate", StringValue("1Mbps")); uc.SetAttribute("PacketSize", UintegerValue(512));
    uc.SetAttribute("OnTime", StringValue("ns3::ConstantRandomVariable[Constant=1]"));
    uc.SetAttribute("OffTime", StringValue("ns3::ConstantRandomVariable[Constant=0]"));
    ApplicationContainer usc=uc.Install(n.Get(1)); usc.Start(Seconds(1)); usc.Stop(Seconds(20));

    access.EnablePcapAll("exp8-access"); bottleneck.EnablePcapAll("exp8-bottleneck");
    FlowMonitorHelper fm; Ptr<FlowMonitor> mon=fm.InstallAll();
    Simulator::Stop(Seconds(20)); Simulator::Run(); mon->CheckForLostPackets();
    Ptr<Ipv4FlowClassifier> cl=DynamicCast<Ipv4FlowClassifier>(fm.GetClassifier());
    for (auto f : mon->GetFlowStats()) {
        auto tuple=cl->FindFlow(f.first); auto s=f.second;
        if (tuple.destinationPort!=tp && tuple.destinationPort!=up) continue;
        double dur=(s.timeLastRxPacket-s.timeFirstTxPacket).GetSeconds();
        double thr=dur>0 ? s.rxBytes*8.0/dur/1e6 : 0;
        double delay=s.rxPackets>0 ? s.delaySum.GetSeconds()*1000.0/s.rxPackets : 0;
        double loss=s.txPackets>0 ? 100.0*(s.txPackets-s.rxPackets)/s.txPackets : 0;
        std::cout << (tuple.destinationPort==tp ? "\\nTCP flow\\n" : "\\nUDP flow\\n");
        std::cout << "Throughput: " << thr << " Mbps\\nAverage delay: " << delay
                  << " ms\\nPacket loss: " << loss << " %\\n";
    }
    Simulator::Destroy(); return 0;
}
