# Performance Metrics — What to Measure and Where

| Program / experiment | Useful measurements | Notes |
|---|---|---|
| TCP request/reply socket | RTT / response time | Client measures from sending request until reply is received. |
| UDP request/reply socket | RTT, timeout count, retry count | UDP does not guarantee delivery; report timeouts/retries. |
| HTTP page download | Response time, bytes received, optional download rate | Current HTTP client measures from sending the request until the server closes the response. |
| DNS-like UDP lookup | RTT, timeout | This is a simplified teaching protocol, not a real DNS implementation. |
| CRC socket program | Error detected / not detected; optional processing time | CRC is an integrity check, not a network performance protocol. |
| NS-3 wired TCP/UDP | Throughput, average delay, packet loss, PDR | TCP retransmission count needs tracing/socket stats; packet loss difference is not an exact retransmission count. |
| NS-3 wireless | Throughput, delay, packet loss, PDR; compare node speeds | Received-power calculation in the sample is illustrative, not a PHY measurement. |

## Formulas
- RTT = time when reply arrives − time when request is sent.
- Throughput (Mbps) = received bytes × 8 / measurement time in seconds / 1,000,000.
- PDR (%) = received packets / transmitted packets × 100.
- Packet loss (%) = (transmitted packets − received packets) / transmitted packets × 100.
- Average delay (ms) = total packet delay / received packets × 1000.
- Retry count = number of times the client resends after a timeout.

Do not force every metric into every program: use metrics that make sense for that task.


## Specific note for the supplied NS-3.29 lab guide
The guide's `two-udp-flows.cc` measures packet count, received bytes, throughput, and average one-way latency using `SeqTsHeader` in custom applications. It does not use FlowMonitor and does not calculate PDR or packet loss. RTT is also not measured by this one-way UDP sender/receiver design.
