# PCN Exam Practice Codes (Likely Question Patterns)

These are practice templates inferred from the topics in your messages and your earlier PCN assignments. They are not predictions of the exact exam questions.

## Contents
- `01_tcp_student_server.c`, `02_tcp_student_client.c` — TCP request/reply using a small student lookup.
- `03_udp_server.c`, `04_udp_client.c` — UDP request/reply with receive timeout and one retry.
- `05_http_get_client.c` — download an HTTP page from a local HTTP server.
- `06_dns_udp_server.c`, `07_dns_udp_client.c` — simplified DNS-like name lookup over UDP (not a real DNS protocol implementation).
- `08_crc_tcp_server.c`, `09_crc_tcp_client.c` — simple CRC demonstration over TCP.
- `ns3_exp8_tcp_udp.cc` — wired TCP/UDP performance analysis (FlowMonitor + PCAP).
- `ns3_exp11_wireless.cc` — simplified wireless mobility/traffic experiment using Wi-Fi ad hoc nodes.
- `METRICS_GUIDE.md` — which performance metrics apply to each program and their formulas.

## Compile/run C socket programs
Run in a Linux terminal. Open two terminals for server and client.

```bash
gcc 01_tcp_student_server.c -o tcp_server
gcc 02_tcp_student_client.c -o tcp_client
./tcp_server
./tcp_client
```

UDP:
```bash
gcc 03_udp_server.c -o udp_server
gcc 04_udp_client.c -o udp_client
./udp_server
./udp_client
```

HTTP client (local server + included `index.html` page):
1. Open a terminal in this folder and start the server:
```bash
python3 -m http.server 8000
```
2. Keep that terminal running. Open a second terminal in the same folder:
```bash
gcc 05_http_get_client.c -o http_client
./http_client
```
The client connects to `127.0.0.1:8000`, sends `GET /`, prints the HTTP response (headers + HTML page), and measures response time. `index.html` is the page being served. You can also visit `http://127.0.0.1:8000` in a browser to check the server.
The HTTP client connects to `127.0.0.1:8000` and requests `/`.

DNS-like UDP lookup:
```bash
gcc 06_dns_udp_server.c -o dns_server
gcc 07_dns_udp_client.c -o dns_client
./dns_server
./dns_client
```

CRC:
```bash
gcc 08_crc_tcp_server.c -o crc_server
gcc 09_crc_tcp_client.c -o crc_client
./crc_server
./crc_client
```

## NS-3 — important version note

Your supplied lab guide is for **NS-3.29**, which uses `waf`. The newer `./ns3 run` commands are for newer NS-3 releases. Do not mix the two command styles.

### For the exact NS-3.29 setup in your guide
Copy `ns3_29_two_udp_flows.cc` into the NS-3.29 `scratch/` directory and rename it `two-udp-flows.cc`. From the inner NS-3.29 folder (the folder containing `waf`), run:

```bash
cd ~/Downloads/ns-allinone-3.29/ns-3.29
nano scratch/two-udp-flows.cc
./waf build
./waf --run scratch/two-udp-flows
```

The program follows your guide: four nodes in a chain, three 5 Mbps / 2 ms links, two UDP flows to Node 3, and custom receiver apps measuring packet count, bytes, throughput, and one-way latency without FlowMonitor.

### Other NS-3 templates in this ZIP
`ns3_exp8_tcp_udp.cc` and `ns3_exp11_wireless.cc` are separate practice templates written with newer-style APIs and may need compatibility changes to run on NS-3.29. Try the guide-specific file first on the lab installation. For Exp 8, the intended variation is to change the bottleneck rate from `2Mbps` to `5Mbps` and `10Mbps` and rerun on a compatible version.

## Metrics quick revision
- Throughput (Mbps) = received bytes × 8 / measurement seconds / 1,000,000
- PDR (%) = received packets / transmitted packets × 100
- Packet loss (%) = (transmitted − received) / transmitted × 100
- Average delay (ms) = total delay / received packets × 1000
- RTT = time from sending a request until its reply arrives.
- TCP retransmission count is not the same as `txPackets - rxPackets`; that difference is only a rough loss estimate. Use TCP tracing/socket statistics if an exact retransmission count is required.
- No ARP program is included, as your message says ARP is not in the exam scope.
