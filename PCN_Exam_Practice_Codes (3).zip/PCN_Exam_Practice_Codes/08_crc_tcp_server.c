// Small TCP receiver for a CRC demo: checks a received bit string using generator 10011.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#define PORT 8090
int main(void) {
    int s = socket(AF_INET, SOCK_STREAM, 0), c;
    struct sockaddr_in a = {0}; char bits[512] = {0}; int i, j, bad = 0;
    char gen[] = "10011";
    a.sin_family = AF_INET; a.sin_addr.s_addr = INADDR_ANY; a.sin_port = htons(PORT);
    if (bind(s, (struct sockaddr *)&a, sizeof(a)) < 0 || listen(s, 1) < 0) { perror("server"); return 1; }
    puts("CRC server waiting..."); c = accept(s, NULL, NULL);
    recv(c, bits, sizeof(bits)-1, 0);
    for (i = 0; bits[i] && i <= (int)strlen(bits)-5; i++) {
        if (bits[i] == '1') for (j = 0; j < 5; j++) bits[i+j] = (bits[i+j] == gen[j]) ? '0' : '1';
    }
    for (i = (int)strlen(bits)-4; i < (int)strlen(bits); i++) if (bits[i] == '1') bad = 1;
    puts(bad ? "CRC: error detected" : "CRC: no error detected");
    close(c); close(s); return 0;
}
