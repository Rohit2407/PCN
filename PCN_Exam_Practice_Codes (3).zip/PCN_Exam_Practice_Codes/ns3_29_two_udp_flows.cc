#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/applications-module.h"
#include <iostream>

using namespace ns3;

class FlowSender : public Application {
public:
    FlowSender() : m_socket(0), m_port(0), m_size(512),
                   m_interval(MilliSeconds(100)), m_seq(0), m_running(false) {}

    void Setup(Ipv4Address dest, uint16_t port, uint32_t size, Time interval) {
        m_dest = dest;
        m_port = port;
        m_size = size;
        m_interval = interval;
    }

private:
    virtual void StartApplication() {
        m_running = true;
        m_socket = Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
        m_socket->Connect(InetSocketAddress(m_dest, m_port));
        SendPacket();
    }

    virtual void StopApplication() {
        m_running = false;
        if (m_event.IsRunning()) Simulator::Cancel(m_event);
        if (m_socket) m_socket->Close();
    }

    void SendPacket() {
        SeqTsHeader h;
        h.SetSeq(m_seq++);
        Ptr<Packet> p = Create<Packet>(m_size - h.GetSerializedSize());
        p->AddHeader(h);
        m_socket->Send(p);
        if (m_running)
            m_event = Simulator::Schedule(m_interval, &FlowSender::SendPacket, this);
    }

    Ptr<Socket> m_socket;
    Ipv4Address m_dest;
    uint16_t m_port;
    uint32_t m_size, m_seq;
    Time m_interval;
    bool m_running;
    EventId m_event;
};

class FlowReceiver : public Application {
public:
    FlowReceiver() : m_socket(0), m_port(0), m_bytes(0), m_packets(0),
                     m_totalDelay(Seconds(0)) {}

    void Setup(uint16_t port) { m_port = port; }
    uint64_t GetBytes() const { return m_bytes; }
    uint32_t GetPackets() const { return m_packets; }

    double GetAverageDelayMs() const {
        return m_packets ? 1000.0 * m_totalDelay.GetSeconds() / m_packets : 0.0;
    }

private:
    virtual void StartApplication() {
        m_socket = Socket::CreateSocket(GetNode(), UdpSocketFactory::GetTypeId());
        m_socket->Bind(InetSocketAddress(Ipv4Address::GetAny(), m_port));
        m_socket->SetRecvCallback(MakeCallback(&FlowReceiver::HandleRead, this));
    }

    virtual void StopApplication() {
        if (m_socket) m_socket->Close();
    }

    void HandleRead(Ptr<Socket> socket) {
        Address from;
        Ptr<Packet> p;
        while ((p = socket->RecvFrom(from))) {
            uint32_t bytes = p->GetSize();
            SeqTsHeader h;
            p->RemoveHeader(h);
            m_bytes += bytes;
            m_packets++;
            m_totalDelay += Simulator::Now() - h.GetTs();
        }
    }

    Ptr<Socket> m_socket;
    uint16_t m_port;
    uint64_t m_bytes;
    uint32_t m_packets;
    Time m_totalDelay;
};

int main() {
    NodeContainer nodes;
    nodes.Create(4);

    PointToPointHelper p2p;
    p2p.SetDeviceAttribute("DataRate", StringValue("5Mbps"));
    p2p.SetChannelAttribute("Delay", StringValue("2ms"));
    NetDeviceContainer d01 = p2p.Install(nodes.Get(0), nodes.Get(1));
    NetDeviceContainer d12 = p2p.Install(nodes.Get(1), nodes.Get(2));
    NetDeviceContainer d23 = p2p.Install(nodes.Get(2), nodes.Get(3));

    InternetStackHelper internet;
    internet.Install(nodes);

    Ipv4AddressHelper ip;
    ip.SetBase("10.1.1.0", "255.255.255.0"); ip.Assign(d01);
    ip.SetBase("10.1.2.0", "255.255.255.0"); ip.Assign(d12);
    ip.SetBase("10.1.3.0", "255.255.255.0");
    Ipv4InterfaceContainer i23 = ip.Assign(d23);
    Ipv4GlobalRoutingHelper::PopulateRoutingTables();

    Ptr<FlowReceiver> r1 = CreateObject<FlowReceiver>();
    r1->Setup(9001);
    nodes.Get(3)->AddApplication(r1);
    r1->SetStartTime(Seconds(0.5));
    r1->SetStopTime(Seconds(9.5));

    Ptr<FlowReceiver> r2 = CreateObject<FlowReceiver>();
    r2->Setup(9002);
    nodes.Get(3)->AddApplication(r2);
    r2->SetStartTime(Seconds(0.5));
    r2->SetStopTime(Seconds(9.5));

    Ptr<FlowSender> s1 = CreateObject<FlowSender>();
    s1->Setup(i23.GetAddress(1), 9001, 512, MilliSeconds(100));
    nodes.Get(0)->AddApplication(s1);
    s1->SetStartTime(Seconds(1));
    s1->SetStopTime(Seconds(9));

    Ptr<FlowSender> s2 = CreateObject<FlowSender>();
    s2->Setup(i23.GetAddress(1), 9002, 1024, MilliSeconds(100));
    nodes.Get(1)->AddApplication(s2);
    s2->SetStartTime(Seconds(1));
    s2->SetStopTime(Seconds(9));

    Simulator::Stop(Seconds(10));
    Simulator::Run();

    double duration = 8.0;
    double t1 = r1->GetBytes() * 8.0 / duration / 1000000.0;
    double t2 = r2->GetBytes() * 8.0 / duration / 1000000.0;

    std::cout << "\n=== UDP RESULTS (no FlowMonitor) ===\n";
    std::cout << "Flow 1: Node 0 -> Node 3, port 9001\n";
    std::cout << "Packets received: " << r1->GetPackets() << "\n";
    std::cout << "Total bytes received: " << r1->GetBytes() << "\n";
    std::cout << "Throughput: " << t1 << " Mbps\n";
    std::cout << "Average packet latency: " << r1->GetAverageDelayMs() << " ms\n\n";

    std::cout << "Flow 2: Node 1 -> Node 3, port 9002\n";
    std::cout << "Packets received: " << r2->GetPackets() << "\n";
    std::cout << "Total bytes received: " << r2->GetBytes() << "\n";
    std::cout << "Throughput: " << t2 << " Mbps\n";
    std::cout << "Average packet latency: " << r2->GetAverageDelayMs() << " ms\n";

    Simulator::Destroy();
    return 0;
}
