// UDP echo/lookup server on port 8081.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#define PORT 8081
int main(void) {
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in a = {0}, client;
    socklen_t n = sizeof(client);
    char msg[256], reply[256];
    a.sin_family = AF_INET; a.sin_addr.s_addr = INADDR_ANY; a.sin_port = htons(PORT);
    if (bind(s, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("bind"); return 1; }
    printf("UDP server listening on port %d\\n", PORT);
    while (1) {
        memset(msg, 0, sizeof(msg)); memset(reply, 0, sizeof(reply));
        recvfrom(s, msg, sizeof(msg)-1, 0, (struct sockaddr *)&client, &n);
        snprintf(reply, sizeof(reply), "UDP server received: %.220s", msg);
        sendto(s, reply, strlen(reply), 0, (struct sockaddr *)&client, n);
    }
}
