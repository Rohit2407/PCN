// Simple TCP student lookup server. Run from the folder containing students.txt.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#define PORT 8080

int main(void) {
    int s = socket(AF_INET, SOCK_STREAM, 0), c;
    struct sockaddr_in a = {0};
    char roll[100], line[256], reply[256] = "Student Record Not Found";
    FILE *fp;
    if (s < 0) { perror("socket"); return 1; }
    a.sin_family = AF_INET; a.sin_addr.s_addr = INADDR_ANY; a.sin_port = htons(PORT);
    if (bind(s, (struct sockaddr *)&a, sizeof(a)) < 0 || listen(s, 5) < 0) {
        perror("bind/listen"); close(s); return 1;
    }
    printf("TCP server listening on port %d\\n", PORT);
    c = accept(s, NULL, NULL);
    if (c < 0) { perror("accept"); close(s); return 1; }
    memset(roll, 0, sizeof(roll));
    recv(c, roll, sizeof(roll)-1, 0);
    fp = fopen("students.txt", "r");
    if (fp) {
        while (fgets(line, sizeof(line), fp)) {
            char saved[100];
            if (sscanf(line, "%99s", saved) == 1 && strcmp(saved, roll) == 0) {
                snprintf(reply, sizeof(reply), "%s", line); break;
            }
        }
        fclose(fp);
    }
    send(c, reply, strlen(reply), 0);
    close(c); close(s); return 0;
}
