// UDP client with a 2-second timeout, one retry, and round-trip-time measurement.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>
#include <arpa/inet.h>
#define PORT 8081
int main(void) {
    int s = socket(AF_INET, SOCK_DGRAM, 0), attempt;
    struct sockaddr_in a = {0};
    struct timeval tv = {2, 0};
    struct timespec start, end;
    char msg[256], reply[256];
    double rtt;
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    a.sin_family = AF_INET; a.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    printf("Enter message: "); fgets(msg, sizeof(msg), stdin);
    for (attempt = 1; attempt <= 2; attempt++) {
        clock_gettime(CLOCK_MONOTONIC, &start);
        sendto(s, msg, strlen(msg), 0, (struct sockaddr *)&a, sizeof(a));
        memset(reply, 0, sizeof(reply));
        if (recvfrom(s, reply, sizeof(reply)-1, 0, NULL, NULL) >= 0) {
            clock_gettime(CLOCK_MONOTONIC, &end);
            rtt = (end.tv_sec-start.tv_sec)*1000.0 + (end.tv_nsec-start.tv_nsec)/1000000.0;
            printf("Reply: %s\\nRTT: %.3f ms\\n", reply, rtt);
            close(s); return 0;
        }
        printf("Timeout on attempt %d\\n", attempt);
    }
    printf("No reply after retry.\\n"); close(s); return 1;
}
