// TCP client: sends a register number to localhost server.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#define PORT 8080

int main(void) {
    int s = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a = {0};
    char roll[100], reply[256] = {0};
    a.sin_family = AF_INET; a.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    printf("Enter register number: ");
    scanf("%99s", roll);
    if (connect(s, (struct sockaddr *)&a, sizeof(a)) < 0) { perror("connect"); return 1; }
    send(s, roll, strlen(roll), 0);
    recv(s, reply, sizeof(reply)-1, 0);
    printf("Server reply: %s\\n", reply);
    close(s); return 0;
}
