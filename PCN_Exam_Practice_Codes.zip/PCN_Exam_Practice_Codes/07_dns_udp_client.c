// DNS-like UDP client with timeout.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <arpa/inet.h>
#define PORT 8053
int main(void) {
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    struct sockaddr_in a = {0}; struct timeval tv = {3, 0};
    char q[256], ans[256] = {0};
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    a.sin_family = AF_INET; a.sin_port = htons(PORT); inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    printf("Domain: "); scanf("%255s", q);
    sendto(s, q, strlen(q), 0, (struct sockaddr *)&a, sizeof(a));
    if (recvfrom(s, ans, sizeof(ans)-1, 0, NULL, NULL) < 0) puts("DNS request timed out");
    else printf("Answer: %s\\n", ans);
    close(s); return 0;
}
