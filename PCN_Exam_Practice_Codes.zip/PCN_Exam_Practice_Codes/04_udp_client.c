// UDP client with a 2-second timeout and one retry.
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <arpa/inet.h>
#define PORT 8081
int main(void) {
    int s = socket(AF_INET, SOCK_DGRAM, 0), attempt;
    struct sockaddr_in a = {0};
    struct timeval tv = {2, 0};
    char msg[256], reply[256];
    setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));
    a.sin_family = AF_INET; a.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &a.sin_addr);
    printf("Enter message: "); fgets(msg, sizeof(msg), stdin);
    for (attempt = 1; attempt <= 2; attempt++) {
        sendto(s, msg, strlen(msg), 0, (struct sockaddr *)&a, sizeof(a));
        memset(reply, 0, sizeof(reply));
        if (recvfrom(s, reply, sizeof(reply)-1, 0, NULL, NULL) >= 0) {
            printf("Reply: %s\\n", reply); close(s); return 0;
        }
        printf("Timeout on attempt %d\\n", attempt);
    }
    printf("No reply after retry.\\n"); close(s); return 1;
}
